"""Authenticate and recover the PDF using the previously recovered chunk order."""
from pathlib import Path
import zipfile,collections
from cryptography.hazmat.primitives.ciphers.aead import AESSIV
R=Path(__file__).resolve().parents[1];out=R/'results';out.mkdir(exist_ok=True)
names=['a74f02f032966a6d','10ffbfd936c82355','fe8fd39f3775309d','3f11d866b82ccda3','26a5b8214563c266','3647358fa35d94e2','4b657989b12f9475','cbc499f0cb7545ea','b08f0c441a53a74a']
with zipfile.ZipFile(R/'evidence/mailbox.zip') as z:
 kn=z.read('e9324da946efad17');tag=z.read('3bca41ad747d8afc');c=b''.join(z.read(n) for n in names)
 p=AESSIV(kn[:64]).decrypt(tag+c,[kn[64:]])
 assert p.startswith(b'%PDF') and len(p)==22806
 (out/'mailbox-report.pdf').write_bytes(p)
 (out/'mailbox-unchunked.png').write_bytes(z.read('91a60f9f6e678d5f'))
 sizes=collections.Counter(i.file_size for i in z.infolist());print('Sizes:',dict(sizes))
 print('AES-SIV authentication passed; report bytes:',len(p))
 print('Chunked image bytes:',(sizes[2534]-9)*2534+60)
