"""Sample-specific Robot 36 luminance reconstruction; not a general SSTV receiver."""
from pathlib import Path
import subprocess
import numpy as np
from scipy.io import wavfile
from scipy.signal import hilbert
from scipy.ndimage import median_filter
from PIL import Image
R=Path(__file__).resolve().parents[1];out=R/'results';out.mkdir(exist_ok=True)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(R/'evidence/signal.mp3'),str(out/'radio.wav')],check=True)
r,x=wavfile.read(out/'radio.wav')
if x.ndim>1:x=x.mean(axis=1)
a=hilbert(x);freq=median_filter(np.angle(a[1:]*a[:-1].conj())*r/(2*np.pi),size=9)
print('Leader Hz:',round(float(np.median(freq[int(.1*r):int(.2*r)]))))
print('Brief break Hz:',round(float(np.median(freq[int(.330*r):int(.334*r)]))))
rows=[]
for line in range(240):
 t=.935+line*.15
 vals=np.interp((t+.012+(np.arange(320)+.5)*.088/320)*r,np.arange(len(freq)),freq);rows.append(vals)
im=np.clip((np.array(rows)-1500)*255/800,0,255).astype('uint8')
Image.fromarray(im).resize((960,720)).save(out/'radio-decoded.png')
print('Inspect results/radio-decoded.png for the decoded text.')
