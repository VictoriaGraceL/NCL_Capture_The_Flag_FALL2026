"""Reimplementation of the supplied hex-string Merkle verifier."""
from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parents[1]
if len(sys.argv)!=3:raise SystemExit('Usage: python scripts/verify_merkle.py LEAF_INDEX HASH')
i=int(sys.argv[1]);h=sys.argv[2]
t=json.loads((R/'evidence/corrupted-tree.json').read_text());a=json.loads((R/'evidence/audit_paths.json').read_text())
entry=next(e for e in a if e['leaf_index']==i)
for sibling in entry['path']:
 h=hashlib.sha256((h+sibling if i%2==0 else sibling+h).encode()).hexdigest();i//=2
print('Computed root:',h);print('Valid:',h==t['expected_root'])
if h!=t['expected_root']:raise SystemExit(1)
