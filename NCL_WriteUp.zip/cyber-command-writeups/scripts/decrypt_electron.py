"""Recheck recorded numeric code; this is not the original brute-force search."""
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
code='2244814';salt=code[::-1].encode().ljust(16,b'\0')
key=HKDF(algorithm=hashes.SHA256(),length=32,salt=salt,info=b'').derive(code.encode())
iv=bytes.fromhex('00795508f644e17b40614686')
c=bytes.fromhex('4fc144d2d6310f4c177ac64c1f')
tag=bytes.fromhex('a7dd2a71e1fd6dad38e387b1291d7191')
print(AESGCM(key).decrypt(iv,c+tag,None).decode())
print('GCM authentication passed.')
