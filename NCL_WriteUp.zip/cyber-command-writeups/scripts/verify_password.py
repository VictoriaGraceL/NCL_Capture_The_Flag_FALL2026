"""Verify the recorded Q3 recovery against the supplied full hash list; not a cracker."""
from pathlib import Path
import hashlib
R=Path(__file__).resolve().parents[1]
h='dd22663a13aaae98c39f0d28cfba52cf';p='ue7680389m03254830'
assert h in (R/'evidence/hashes.txt').read_text().split()
actual=hashlib.md5(p.encode()).hexdigest()
assert actual==h
print(f'{h}:{p}\nMD5 verified; target present in full input hash list.')
