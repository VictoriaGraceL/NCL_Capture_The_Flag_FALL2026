# Screenshot-by-screenshot evidence guide

Original images are preserved unchanged. Captions distinguish visible facts from interpretation. Screenshots are not fabricated to fill gaps.

| # | Challenge | Evidence |
|---|---|---|
| 01 | water-wells | [Water-well questions](screenshots/01-water-wells.md) |
| 02 | aes-gcm | [Encryption challenge questions](screenshots/02-aes-gcm.md) |
| 03 | aes-gcm | [Plaintext flag question](screenshots/03-aes-gcm.md) |
| 04 | aes-gcm | [Encrypted payload](screenshots/04-aes-gcm.md) |
| 05 | hidden-packets | [Initial packet-capture view](screenshots/05-hidden-packets.md) |
| 06 | finance-mitm | [Finance capture overview](screenshots/06-finance-mitm.md) |
| 07 | firewall-knocks | [Local interface inventory](screenshots/07-firewall-knocks.md) |
| 08 | firewall-knocks | [Routing and local files](screenshots/08-firewall-knocks.md) |
| 09 | firewall-knocks | [Hosts and neighbor check](screenshots/09-firewall-knocks.md) |
| 10 | firewall-knocks | [Resumed interface check](screenshots/10-firewall-knocks.md) |
| 11 | firewall-knocks | [ARP host discovery](screenshots/11-firewall-knocks.md) |
| 12 | firewall-knocks | [Background capture attempt](screenshots/12-firewall-knocks.md) |
| 13 | smb-sync | [Share discovery and placeholder error](screenshots/13-smb-sync.md) |
| 14 | smb-sync | [Remote sync listing](screenshots/14-smb-sync.md) |
| 15 | smb-sync | [Shell/client prompt confusion](screenshots/15-smb-sync.md) |
| 16 | smb-sync | [README download succeeded](screenshots/16-smb-sync.md) |
| 17 | smb-sync | [README read in shell](screenshots/17-smb-sync.md) |
| 18 | smb-sync | [File ACL versus root ACL](screenshots/18-smb-sync.md) |
| 19 | smb-sync | [Configuration and script contents](screenshots/19-smb-sync.md) |
