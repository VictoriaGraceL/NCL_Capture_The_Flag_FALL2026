# Contributions and provenance

## Viktoriia

Collected and uploaded challenge prompts, packet captures, binary logs, images, audio, password lists and encrypted payloads; ran hosted-terminal commands; supplied screenshots and rejection feedback; chose investigation priorities; requested a team handoff and a GitHub portfolio.

## ChatGPT assistance

Helped interpret prompts and evidence, supplied commands, wrote analysis scripts, reconstructed/decrypted content, and organized results. Current scripts are reconstructed reproducibility tools, not a recovered full shell history. This record is collaborative and does not portray all automated analysis as independently authored by Viktoriia.

## Scope and limitations

The original seven-page PDF is preserved unchanged. New Markdown updates the later firewall discovery and SMB screenshots. The archive includes only relevant challenge material. It does not infer missing platform acceptance or manufacture screenshots. Original binary-parser and crack-all scripts did not survive transient workspace cleanup; the write-ups preserve available methods and inputs, while the packaged verifier checks the known recovered password.

Screenshot filenames retain capture identifiers; their embedded date/time strings are not treated as authoritative local timestamps. Plaintext passwords, flags and usernames are from the supplied CTF data.
