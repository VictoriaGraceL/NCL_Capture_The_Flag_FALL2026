# Password audit: candidate generation and verification

**Status:** Q3 recovered; full original cracking script unavailable.

## Inputs and answers
- `evidence/lastyear.potfile`: previous hash:password pairs.
- `evidence/hashes.txt`: all current hashes, intentionally more than the scored questions.
- Q1 and Q2 were marked Completed in the supplied prompt; their plaintexts were not recorded in this conversation.
- Q3: `dd22663a13aaae98c39f0d28cfba52cf` → `ue7680389m03254830`.

## Clues from already cracked passwords
`berwockyjschachror`, `inAdminrarwo`, and `!anyonHSV68@F` suggested substring/combination transformations rather than simply reusing last year's full passwords.

## Recorded approach
1. Extract plaintexts from last year's potfile, splitting only on the first colon.
2. Compare supplied cracked examples with pieces of previous passwords.
3. Generate concatenated circular-substring candidates and compare against the **full** current hash set.
4. Feed newly recovered passwords into later candidate rounds.
5. Verify each claimed result with a direct MD5 computation.

The earlier session notes record iterative candidate recovery. Exact hashcat-utils commands, substring bounds, and the original cracking program were not retained. This archive does not invent them or label a guessed command as executed.

## Reproduce the verified result
```bash
python scripts/verify_password.py
```
This checks the target hash is present in the supplied full hash list and validates its plaintext. It is a verifier, not a complete crack-all implementation. `results/password-verification.txt` records the actual run.

## Why it matters
Changing a password by recombining recognizable fragments can remain predictable even when an old whole-word dictionary no longer works. The transferable skill is inferring candidate transformations from known examples, then verifying exact hashes.

No password-cracking terminal screenshot was supplied; the included verification output is newly generated and labeled accordingly.

## Screenshot evidence

No original terminal screenshot was supplied for this challenge. See inputs and recorded results.

[Repository home](../../README.md)
