# Covert traffic: sent versus delivered

**Status:** Earlier recovered analysis.

Answers: destination `68.66.248.4`; usual utility `traceroute` (Windows `tracert` accepted by prompt); hidden flag `SKY-YQAA-0017`; message actually received `!`.

Open `evidence/bad_exfil.pcap`. Look beyond the opening IPv6 router advertisements. Follow outgoing probes, embedded payloads, TTL progression and ICMP responses. Earlier analysis found that the earlier probes expired along the path; only the final payload reached the destination, supported by its port-unreachable response. Do not equate a flag visible in a sender-side capture with the bytes received at the final host.

## Screenshot evidence

- [Initial packet-capture view](../screenshots/05-hidden-packets.md)

[Repository home](../../README.md)
