# SMTP exfiltration: Meridian Fabrication

**Status:** Earlier recovered analysis.

| Question | Recorded answer |
|---|---|
| Q1 | `application/zip` |
| Q2 | `gmail.com` |
| Q3 | `10.12.4.51` |
| Q4 | `j.reyes@meridianfab.com` |
| Q5 | `41441661510ca959894e374fc29205a3` |
| Q6 | `3567196` |

Unpack `evidence/outbound-traffic-logs.zip`. Read the Zeek #fields headers before parsing tab-separated rows. Correlate SMTP sessions to file IDs; identify engineering-source outbound messages and destination d.harmon.freight@gmail.com. Earlier analysis found five ZIP attachments disguised as image/PDF filenames. Count unique relevant file records and sum their seen_bytes, not SMTP connection bytes or filenames. Select the largest relevant attachment before reading its MD5.

The gmial.com typo attempt failed and contained no attachments. Do not add it to successful exfiltration. Original analysis code is not retained; the original logs are included for independent reproduction.

## Screenshot evidence

No original terminal screenshot was supplied for this challenge. See inputs and recorded results.

[Repository home](../../README.md)
