# Merkle tree: corrupted record

**Status:** Partial; tampered-field answer disputed.

Recorded corrupted index: `5`.

Second audit-path hash:
`c7d8d7bffe4cbcbba079395c4c8e7b23856abcaa711bd1bc71f7b23aba44748d`

Sibling:
`05a738ebfed33488d78a59bb3cc1c5cc57fdeec44893093c756d937b6cc948c2`

Recorded correct leaf:
`42d9bf34bffe15cb8c09a9352d16b35f02213bec2f2e35420e5e7553ccb518db`

Corrected parent:
`c1e753564f883378ea3d96231fd26d769e44eb4ced1dcede9c5483036251564c`

The supplied verifier hashes concatenated **hexadecimal strings**, not binary digest bytes. At each level, leaf-index parity determines left/right order. Compare reconstructed root against expected_root.

Run `python scripts/verify_merkle.py 5 42d9bf34bffe15cb8c09a9352d16b35f02213bec2f2e35420e5e7553ccb518db`.

Earlier notes associated 9.726 versus 9.7261 with the amount field, but the user reported that amount was rejected. That question remains unresolved; the verification of a proposed hash does not establish the grader's accepted field answer.

## Screenshot evidence

No original terminal screenshot was supplied for this challenge. See inputs and recorded results.

[Repository home](../../README.md)
