# Empires of Il’thon: infinite-money patterns

**Status:** Earlier recovered analysis.

| Question | Recorded answer |
|---|---|
| Q1 | `519745` increase |
| Q2 | `5159` |
| Q3 | `155023` |
| Q4 | `51` |
| Q5 | `mcdougal` |
| Q6 | `Demon-Touched Iron Shield` |
| Q7 | `12264431` |
| Q8 | `64347` increase |
| Q10 | `50` |
| Q11 | `Demon-Touched Iron Shield, Purified Demon-Touched Staff` |
| Q12 | `32861021` |
| Q13 | `298087` |

Q9 (one comma-separated list):
```
0326324d-fb69-4ffb-ba18-90c78092b4d4, 2b28fef0-2b9c-414e-a5ac-06d864c2f2e3, 678a5aa3-3b6f-4507-8c5f-e8f8dc3bf364, 9403560d-97da-438d-9d64-3c25fbb230bb, d92a4aa2-b410-493c-8efb-c8d60b21fbac, eb8ac8ce-8a24-4e6b-b313-8131c541013d
```

### Binary format notes retained from analysis
ZHDR + big-endian uint32 length + ASCII schema; ZVAL + big-endian uint32 payload length. UUID values occupy 16 bytes; integer/time fields are signed big-endian 8-byte values; string/enum fields have a 2-byte length; optional fields use a flag byte; maps and lists begin with uint32 counts. Read each actual schema before interpreting records.

### Investigation
Join item metadata to market operations and player starting inventories. Sum all gold deltas for Q1. Count 5159 initial entries for online users, not only the 4822 players with updates. Sum quantities sold, not transaction count. Compare buy/sell sequences and market stock/price changes to find repeating profitable cycles. Separate the solo farmer from the 50-person ring (25 associated with each item in earlier notes). Reconcile market cash flows against player updates.

Ring total gold increase 298281 includes 194 dungeon gold; trading-only profit is 298087. Q9 compares purchased UUIDs with the solo user's initial inventory. The five original binary inputs are included; original parser/analysis scripts were transient and are not represented as retained code.

## Screenshot evidence

No original terminal screenshot was supplied for this challenge. See inputs and recorded results.

[Repository home](../../README.md)
