# Electron encryption: weak numeric keycode

**Status:** Earlier authenticated recovery recorded.

Answers: cipher mode `GCM`; flag `SKY-AZNP-6151`; recovered keycode `2244814`.

The application validates a 5–7 digit numeric string, reverses it, zero-pads that UTF-8 value to a 16-byte salt, and runs HKDF-SHA256 with empty info for a 32-byte key. Encryption is AES-256-GCM with a random 12-byte IV and a 16-byte tag.

The limited numeric input space makes offline candidate testing possible; HKDF does not add input entropy. A candidate must pass GCM authentication, not merely produce plausible-looking text. `scripts/decrypt_electron.py` uses the recovered code and the screenshot's exact payload to verify the result again. It does not reproduce the earlier search.

### Run
`python scripts/decrypt_electron.py`

## Screenshot evidence

- [Encryption challenge questions](../screenshots/02-aes-gcm.md)
- [Plaintext flag question](../screenshots/03-aes-gcm.md)
- [Encrypted payload](../screenshots/04-aes-gcm.md)

[Repository home](../../README.md)

## Transcription correction during packaging

A cursor obscures one IV character in the screenshot. The first transcription used `007955b8...` and failed authentication. Testing that obscured character recovered `00795508f644e17b40614686`; this IV passes GCM authentication and produces the recorded flag. The packaged script uses the authenticated value.
