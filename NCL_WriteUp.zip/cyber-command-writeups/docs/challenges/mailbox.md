# Mixed mailbox: AES-SIV reconstruction

**Status:** Authenticated report recovered.

| Question | Answer |
|---|---|
| Q1 | `TRY AGAIN` |
| Q2 | `1429236` |
| Q3 | `22806` |
| Q4 | `Fin, Zeno` |

### Investigation
577 files: 573 × 2534 bytes, plus 590, 60, 16 and 96-byte files. Identify PNG signatures; the 590-byte PNG is the complete image. Split the 96-byte file into a 64-byte key and 32-byte nonce. The 16-byte file is the authentication tag.

AES-SIV uses a synthetic IV to generate a CTR keystream. Earlier analysis applied the keystream at each possible 2534-byte offset, identified PDF syntax, and used successful zlib continuation to narrow the middle chunks. The final AES-SIV tag authenticated the chosen order. The script here reproduces decryption using that recovered order; it does not pretend to rediscover the order.

Report size: 9 × 2534 = 22806 bytes. Remaining image: 564 × 2534 + 60 = 1429236 bytes. This accounting assumes the three-message inventory given by the prompt; the large image was not reconstructed.

### Reproduce
Run `python scripts/decrypt_mailbox.py`, then `pdftotext -layout results/mailbox-report.pdf -`. The report says Fin was lost; Xavier and Yan were recovered; Zeno was left behind.

![Unchunked image](../../results/mailbox-unchunked.png)

## Screenshot evidence

No original terminal screenshot was supplied for this challenge. See inputs and recorded results.

[Repository home](../../README.md)
