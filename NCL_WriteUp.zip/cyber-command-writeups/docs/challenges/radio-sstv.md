# Radio transmission: SSTV image decoding

**Status:** Decoded image recovered.

| Question | Answer |
|---|---|
| Q1 | `1900 Hz` |
| Q2 | `1200 Hz` |
| Q3 | `SSTV` |
| Q4 | `Robot 36` |
| Q5 | `SKY-TELE-9482` |

### Investigation
Convert MP3 to PCM. Inspect the first second with fine time resolution: a short 1200 Hz break around 0.33 s interrupts the 1900 Hz leader. Read the VIS symbols: mode code 8 corresponds to Robot 36. Decode the luminance channel using 150 ms lines, with a 9 ms sync, 3 ms porch and 88 ms luminance scan. The flag is visible in the reconstructed image.

### Reproduce
Run `python scripts/decode_radio.py`. Requires ffmpeg, numpy, scipy and Pillow. This is a sample-specific luminance decoder, not a general color SSTV implementation. It intentionally preserves the decoded result rather than claiming a perfect full-color reconstruction.

Reference used during investigation: https://sstv-handbook.com/download/sstv_03.pdf .

![Recovered luminance](../../results/radio-decoded.png)

## Screenshot evidence

No original terminal screenshot was supplied for this challenge. See inputs and recorded results.

[Repository home](../../README.md)
