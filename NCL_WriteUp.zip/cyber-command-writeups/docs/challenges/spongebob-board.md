# Spongebob image board

**Status:** Partial: route and source filename found.

Q1 `/get_file`; Q2 `server.js`; Q3 flag not recovered.

The supplied download link used `file=meme1.jpeg` plus a session-specific uid. A live home-page fetch returned an HTML comment stating that static files and uploads are served by the Express app in server.js. That grounds the filename; it does not mean the source code was downloaded.

The five original downloaded meme files are included under evidence/get_file*. No page screenshot or application-source download was provided. No successful traversal or flag retrieval is recorded. The challenge required an instance refresh after a fix and said fuzzing/brute forcing were unnecessary. Session hostnames and uid values are omitted from the README because they are ephemeral. No live requests are made by the packaged scripts.

## Screenshot evidence

No original terminal screenshot was supplied for this challenge. See inputs and recorded results.

[Repository home](../../README.md)
