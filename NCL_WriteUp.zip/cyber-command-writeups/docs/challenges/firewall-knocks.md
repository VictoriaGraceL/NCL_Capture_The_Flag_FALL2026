# Ordered firewall knocks

**Status:** Paused; no returned flags recorded.

Local address: 10.13.203.36/27. ARP discovery found peers 10.13.203.33, .34 and .35; target not confirmed. This updates the older PDF, which predates the discovery screenshot.

### Clues, not submission answers
1. ping → ICMP echo request.
2. udp rhenium → destination port 75.
3. udp third Mersenne prime → port 31.
4. udp eleet → port 1337.
5. Alphabet generator / reflector suggests chargen (19) and echo (7); exact direction unresolved.
6. The question whose answer is 42: exact payload/protocol unresolved.

### Commands actually shown
```bash
ip -br addr
ip route
ls -la
cat /etc/hosts
ip neigh
nmap -sn -PR 10.13.203.32/27
```
A background tcpdump command was attempted, apparently misspelled. A job ID alone is not evidence of recording. No screenshot shows completed ping tests or returned flags. Proposed diagnostics were cat /tmp/knocks-capture.log and tcpdump -nn -A -r /tmp/knocks.pcap; successful output was not provided. Preserve this distinction when describing the work.

## Screenshot evidence

- [Local interface inventory](../screenshots/07-firewall-knocks.md)
- [Routing and local files](../screenshots/08-firewall-knocks.md)
- [Hosts and neighbor check](../screenshots/09-firewall-knocks.md)
- [Resumed interface check](../screenshots/10-firewall-knocks.md)
- [ARP host discovery](../screenshots/11-firewall-knocks.md)
- [Background capture attempt](../screenshots/12-firewall-knocks.md)

[Repository home](../../README.md)
