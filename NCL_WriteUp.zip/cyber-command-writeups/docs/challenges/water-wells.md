# Michigan water-well research

**Status:** Unsolved.

The questions ask for the well nearest 8450 West 10 Mile Road outside Detroit and the deepest household well in Augusta, Kalamazoo County, Michigan. No supported depth was recovered. The prompt screenshot is included. Future investigation needs the appropriate official well records and location/type filtering; there are no numerical answers to carry forward.

## Screenshot evidence

- [Water-well questions](../screenshots/01-water-wells.md)

[Repository home](../../README.md)
