# Finance workstation: ARP poisoning and authentication relay

**Status:** Evidence-backed answers.

| Question | Answer |
|---|---|
| Q1 | `00:0c:29:37:f8:82` |
| Q2 | `10.33.20.77` |
| Q3 | `FSO1` (letter O) |
| Q4 | `RICHARDSON\wdavila` |
| Q5 | `10.33.20.174` |
| Q6 | `INV-6829-6598` |

### Investigation
1. Read the full 867-packet capture, not just its discovery traffic.
2. Group ARP sender-IP claims by MAC. The rogue MAC claims the gateway to victim 10.33.20.170 and the victim to the gateway.
3. Keep benign failover host 10.33.20.77 (00:1b:0c:47:48:47, ric-gw02) separate from attacker 10.33.20.24.
4. Packets 505–506 show LLMNR lookup FSO1 and the forged reply pointing to the attacker.
5. Packets 533–534 show victim authentication and its relay to 10.33.20.174.
6. Packet 562 includes the recovered file's Reference value.

### Reproduce in Wireshark
Open `evidence/capture.pcap` (pcapng despite its extension). Apply `arp`, then `llmnr`, then `ntlmssp`. Jump to packets 505, 506, 533, 534 and 562. Read the account and file content directly. Avoid treating every duplicate gateway ARP as malicious.

## Screenshot evidence

- [Finance capture overview](../screenshots/06-finance-mitm.md)

[Repository home](../../README.md)
