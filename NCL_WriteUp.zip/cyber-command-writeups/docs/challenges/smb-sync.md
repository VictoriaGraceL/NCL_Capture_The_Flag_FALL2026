# SMB sync share: overly broad file ACL

**Status:** Q4/Q5 supported; root flag unresolved.

| Question | Finding |
|---|---|
| Q1 | `sync` |
| Q2 | `smbcacls` |
| Q3 | `heartbeat.sh` is the working file; scheduled root execution comes from challenge context, not a captured cron listing |
| Q4 | `Everyone` |
| Q5 | `READ` |
| Q6 | Not recovered |

Lab credentials supplied by the challenge: analyst / analyst123. These are challenge-only credentials, visible in original screenshots.

### Step-by-step session
1. List shares; identify sync and IPC$.
2. Correct the literal SHARE_NAME placeholder error by connecting to //target/sync.
3. Use ls inside smbclient to inspect remote files.
4. Attempting cat inside smbclient fails because this is not the shell.
5. Download README.txt with get; exit to root@debian; read local copy with cat.
6. Download config and heartbeat.sh. Inspect ACLs on the file and on /.
7. File ACL shows Everyone RW, while directory ACL shows Everyone READ. Existing-file write rights can differ from directory creation rights.
8. The final script shown is `ls -la /root > flag.log`. It lists the directory, not the flag's contents. We did not observe who wrote that version or a successful root-run result.

### Read-only inspection commands recorded
```bash
smbclient -L //target -U 'analyst%analyst123'
smbclient //target/sync -U 'analyst%analyst123'
```
Inside smbclient:
```text
ls
get README.txt /tmp/sync-readme.txt
exit
```
Back in shell:
```bash
cat /tmp/sync-readme.txt
smbclient //target/sync -U 'analyst%analyst123' -c 'get sync_config.ini /tmp/sync-config.ini; get heartbeat.sh /tmp/sync-heartbeat.sh'
cat /tmp/sync-config.ini /tmp/sync-heartbeat.sh
smbcacls //target/sync heartbeat.sh -U 'analyst%analyst123'
smbcacls //target/sync / -U 'analyst%analyst123'
```

No root flag or successful privilege-escalation output is present. Do not label this fully solved. A security fix would remove unnecessary write access from the root-processed file and avoid privileged execution of share-controlled content.

## Screenshot evidence

- [Share discovery and placeholder error](../screenshots/13-smb-sync.md)
- [Remote sync listing](../screenshots/14-smb-sync.md)
- [Shell/client prompt confusion](../screenshots/15-smb-sync.md)
- [README download succeeded](../screenshots/16-smb-sync.md)
- [README read in shell](../screenshots/17-smb-sync.md)
- [File ACL versus root ACL](../screenshots/18-smb-sync.md)
- [Configuration and script contents](../screenshots/19-smb-sync.md)

[Repository home](../../README.md)
