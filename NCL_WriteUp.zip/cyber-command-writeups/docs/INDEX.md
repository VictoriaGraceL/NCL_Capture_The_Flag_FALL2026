# Challenge index

| Challenge | Status |
|---|---|
| [Finance workstation: ARP poisoning and authentication relay](challenges/finance-mitm.md) | Evidence-backed answers |
| [Radio transmission: SSTV image decoding](challenges/radio-sstv.md) | Decoded image recovered |
| [Mixed mailbox: AES-SIV reconstruction](challenges/mailbox.md) | Authenticated report recovered |
| [Password audit: candidate generation and verification](challenges/password-audit.md) | Q3 recovered; full original cracking script unavailable |
| [Electron encryption: weak numeric keycode](challenges/aes-gcm.md) | Earlier authenticated recovery recorded |
| [SMTP exfiltration: Meridian Fabrication](challenges/smtp-exfiltration.md) | Earlier recovered analysis |
| [Collaborative editor: operation replay](challenges/editor-log.md) | Earlier recovered analysis |
| [Empires of Il’thon: infinite-money patterns](challenges/game-economy.md) | Earlier recovered analysis |
| [Covert traffic: sent versus delivered](challenges/hidden-packets.md) | Earlier recovered analysis |
| [Merkle tree: corrupted record](challenges/merkle-tree.md) | Partial; tampered-field answer disputed |
| [Physical key photographs](challenges/key-bitting.md) | Brands recorded; bitting unresolved |
| [Michigan water-well research](challenges/water-wells.md) | Unsolved |
| [Spongebob image board](challenges/spongebob-board.md) | Partial: route and source filename found |
| [Ordered firewall knocks](challenges/firewall-knocks.md) | Paused; no returned flags recorded |
| [SMB sync share: overly broad file ACL](challenges/smb-sync.md) | Q4/Q5 supported; root flag unresolved |
