# 04. Encrypted payload

![Encrypted payload](../../screenshots/04-aes-gcm-20261108-000423.png)

## What is visible

Contains hexadecimal IV, ciphertext and authentication tag.

## Interpretation and limitation

Used with the provided HKDF/AES-GCM code; preserve hex exactly.

## Source

Original upload: `image(20261108-000423).png`. These timestamps are filenames supplied by the capture workflow; no timezone conversion is assumed.

[Back to screenshot index](../SCREENSHOTS.md)
