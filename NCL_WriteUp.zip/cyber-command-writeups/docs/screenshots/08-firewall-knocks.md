# 08. Routing and local files

![Routing and local files](../../screenshots/08-firewall-knocks-20261108-010104.png)

## What is visible

ip route reports connected network 10.13.203.32/27; ls lists the local home directory.

## Interpretation and limitation

No dev-box address is established by this output.

## Source

Original upload: `image(20261108-010104).png`. These timestamps are filenames supplied by the capture workflow; no timezone conversion is assumed.

[Back to screenshot index](../SCREENSHOTS.md)
