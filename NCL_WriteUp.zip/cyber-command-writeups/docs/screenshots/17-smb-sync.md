# 17. README read in shell

![README read in shell](../../screenshots/17-smb-sync-20261108-174346.png)

## What is visible

After exit, cat succeeds. README describes periodic automation and warns against deleting or renaming files.

## Interpretation and limitation

Confirms purpose of the share, but does not expose the flag.

## Source

Original upload: `image(20261108-174346).png`. These timestamps are filenames supplied by the capture workflow; no timezone conversion is assumed.

[Back to screenshot index](../SCREENSHOTS.md)
