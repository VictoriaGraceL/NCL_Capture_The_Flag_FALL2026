# 19. Configuration and script contents

![Configuration and script contents](../../screenshots/19-smb-sync-20261108-174608.png)

## What is visible

Config shows enabled=true, retry=3, timeout=30, level=info, rotate=daily. The downloaded script reads: ls -la /root > flag.log.

## Interpretation and limitation

That command lists /root; it does not read /root/flag.txt. No recovered flag is shown; origin of that script modification is not established.

## Source

Original upload: `image(20261108-174608).png`. These timestamps are filenames supplied by the capture workflow; no timezone conversion is assumed.

[Back to screenshot index](../SCREENSHOTS.md)
