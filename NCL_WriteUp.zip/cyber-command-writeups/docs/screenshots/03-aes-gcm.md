# 03. Plaintext flag question

![Plaintext flag question](../../screenshots/03-aes-gcm-20261108-000338.png)

## What is visible

Shows the outstanding flag question.

## Interpretation and limitation

Answer status at capture time is incomplete.

## Source

Original upload: `image(20261108-000338).png`. These timestamps are filenames supplied by the capture workflow; no timezone conversion is assumed.

[Back to screenshot index](../SCREENSHOTS.md)
