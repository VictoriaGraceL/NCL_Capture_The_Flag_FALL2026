# 07. Local interface inventory

![Local interface inventory](../../screenshots/07-firewall-knocks-20261108-010033.png)

## What is visible

ip -br addr reports eth0 at 10.13.203.36/27.

## Interpretation and limitation

This is the client address, not the target.

## Source

Original upload: `image(20261108-010033).png`. These timestamps are filenames supplied by the capture workflow; no timezone conversion is assumed.

[Back to screenshot index](../SCREENSHOTS.md)
