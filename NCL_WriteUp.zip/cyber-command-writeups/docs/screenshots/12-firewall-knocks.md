# 12. Background capture attempt

![Background capture attempt](../../screenshots/12-firewall-knocks-20261108-160320.png)

## What is visible

A capture command was entered and the shell returned [1] 82.

## Interpretation and limitation

The command appears misspelled; a background job ID does not prove tcpdump worked. No captured reply is shown.

## Source

Original upload: `image(20261108-160320).png`. These timestamps are filenames supplied by the capture workflow; no timezone conversion is assumed.

[Back to screenshot index](../SCREENSHOTS.md)
