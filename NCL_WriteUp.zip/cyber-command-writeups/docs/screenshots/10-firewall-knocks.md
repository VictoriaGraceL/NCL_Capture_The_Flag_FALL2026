# 10. Resumed interface check

![Resumed interface check](../../screenshots/10-firewall-knocks-20261108-155614.png)

## What is visible

The client is still 10.13.203.36/27.

## Interpretation and limitation

The same subnet can be used for local host discovery.

## Source

Original upload: `image(20261108-155614).png`. These timestamps are filenames supplied by the capture workflow; no timezone conversion is assumed.

[Back to screenshot index](../SCREENSHOTS.md)
