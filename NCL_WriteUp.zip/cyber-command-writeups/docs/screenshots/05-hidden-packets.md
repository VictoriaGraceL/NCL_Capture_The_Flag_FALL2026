# 05. Initial packet-capture view

![Initial packet-capture view](../../screenshots/05-hidden-packets-20261108-005405.png)

## What is visible

The visible rows are IPv6 router advertisements.

## Interpretation and limitation

These first rows do not reveal the covert destination. Inspect the full capture.

## Source

Original upload: `image(20261108-005405).png`. These timestamps are filenames supplied by the capture workflow; no timezone conversion is assumed.

[Back to screenshot index](../SCREENSHOTS.md)
