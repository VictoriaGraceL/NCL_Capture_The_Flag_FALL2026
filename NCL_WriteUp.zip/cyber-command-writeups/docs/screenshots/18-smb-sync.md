# 18. File ACL versus root ACL

![File ACL versus root ACL](../../screenshots/18-smb-sync-20261108-174513.png)

## What is visible

File ACL grants Everyone RW; share-root ACL grants Everyone READ.

## Interpretation and limitation

Q4 is Everyone and Q5 is READ. A read-only directory does not eliminate write rights on an existing file.

## Source

Original upload: `image(20261108-174513).png`. These timestamps are filenames supplied by the capture workflow; no timezone conversion is assumed.

[Back to screenshot index](../SCREENSHOTS.md)
