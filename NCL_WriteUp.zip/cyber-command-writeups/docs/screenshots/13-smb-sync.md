# 13. Share discovery and placeholder error

![Share discovery and placeholder error](../../screenshots/13-smb-sync-20261108-174144.png)

## What is visible

The available disk share is sync. Entering SHARE_NAME literally causes NT_STATUS_BAD_NETWORK_NAME.

## Interpretation and limitation

The later ls is local shell output, not the remote share. Use //target/sync.

## Source

Original upload: `image(20261108-174144).png`. These timestamps are filenames supplied by the capture workflow; no timezone conversion is assumed.

[Back to screenshot index](../SCREENSHOTS.md)
