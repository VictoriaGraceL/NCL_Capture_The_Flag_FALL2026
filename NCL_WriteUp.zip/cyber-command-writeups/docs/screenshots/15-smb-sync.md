# 15. Shell/client prompt confusion

![Shell/client prompt confusion](../../screenshots/15-smb-sync-20261108-174248.png)

## What is visible

cat was entered at smb: \> and returned command not found.

## Interpretation and limitation

cat is a shell command; download with get, exit smbclient, then read locally.

## Source

Original upload: `image(20261108-174248).png`. These timestamps are filenames supplied by the capture workflow; no timezone conversion is assumed.

[Back to screenshot index](../SCREENSHOTS.md)
