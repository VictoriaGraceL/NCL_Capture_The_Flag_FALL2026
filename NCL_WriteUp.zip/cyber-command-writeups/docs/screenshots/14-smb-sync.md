# 14. Remote sync listing

![Remote sync listing](../../screenshots/14-smb-sync-20261108-174210.png)

## What is visible

At smb: \>, files include heartbeat.sh, heartbeat.log, sync_config.ini, cleanup.sh, README.txt and notify.sh.

## Interpretation and limitation

This is the remote listing. The screenshot alone does not prove which scheduled job runs as root.

## Source

Original upload: `image(20261108-174210).png`. These timestamps are filenames supplied by the capture workflow; no timezone conversion is assumed.

[Back to screenshot index](../SCREENSHOTS.md)
