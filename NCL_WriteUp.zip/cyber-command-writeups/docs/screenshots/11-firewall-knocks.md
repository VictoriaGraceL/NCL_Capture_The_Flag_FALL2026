# 11. ARP host discovery

![ARP host discovery](../../screenshots/11-firewall-knocks-20261108-160001.png)

## What is visible

nmap -sn -PR found .33, .34, .35 and local .36.

## Interpretation and limitation

Three peer hosts were discovered; none was yet proven to be the dev box.

## Source

Original upload: `image(20261108-160001).png`. These timestamps are filenames supplied by the capture workflow; no timezone conversion is assumed.

[Back to screenshot index](../SCREENSHOTS.md)
