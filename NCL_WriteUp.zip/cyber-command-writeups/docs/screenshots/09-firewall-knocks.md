# 09. Hosts and neighbor check

![Hosts and neighbor check](../../screenshots/09-firewall-knocks-20261108-010213.png)

## What is visible

/etc/hosts contains the local kali mapping; ip neigh prints no neighbors.

## Interpretation and limitation

No target mapping was found.

## Source

Original upload: `image(20261108-010213).png`. These timestamps are filenames supplied by the capture workflow; no timezone conversion is assumed.

[Back to screenshot index](../SCREENSHOTS.md)
