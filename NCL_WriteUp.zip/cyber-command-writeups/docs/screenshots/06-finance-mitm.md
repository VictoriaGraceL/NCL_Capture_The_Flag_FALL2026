# 06. Finance capture overview

![Finance capture overview](../../screenshots/06-finance-mitm-20261108-005559.png)

## What is visible

Shows routine discovery and DNS packets at the beginning of the capture.

## Interpretation and limitation

The attack is later in the capture; packet numbers in the write-up point to the evidence.

## Source

Original upload: `image(20261108-005559).png`. These timestamps are filenames supplied by the capture workflow; no timezone conversion is assumed.

[Back to screenshot index](../SCREENSHOTS.md)
