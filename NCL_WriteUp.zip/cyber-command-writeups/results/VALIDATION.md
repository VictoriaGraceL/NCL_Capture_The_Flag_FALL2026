# Packaging validation

These checks were actually run while building this archive:

| Check | Result |
|---|---|
| Q3 password MD5 and full-list membership | PASS |
| Leaf 5 proof against expected Merkle root | PASS |
| AES-GCM recovered code and corrected IV | PASS; authenticated SKY-AZNP-6151 |
| Nine-chunk AES-SIV PDF reconstruction | PASS; authentication tag accepted |
| Mailbox byte accounting | PASS; 22806 report / 1429236 chunked image |
| Radio frequency estimates | 1900 Hz leader / approximately 1202 Hz short break |
| Radio image visual inspection | SKY-TELE-9482 visible |
| Markdown internal link check | PASS |
| ZIP integrity | PASS |

Output transcripts are saved alongside this file. Passing the Merkle proof does not resolve the disputed field-name answer. Finance/SMTP/game/editor/covert-packet findings were not recomputed during packaging; their evidence and earlier methods are retained.

No original screenshots exist for every computation. The 19 supplied screenshots are documented individually. Missing original crack-all and binary-parser code is explicitly disclosed in the write-ups; no synthetic terminal screenshots substitute for it.
